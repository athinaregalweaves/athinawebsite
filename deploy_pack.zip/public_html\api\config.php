<?php
// ============================================
// GLOBAL CONFIGURATION - Athina Regal Weaves
// ============================================

// Site settings
define('SITE_NAME', 'Athina Regal Weaves');
define('SITE_EMAIL', 'info@athinaregalweaves.com');
define('SITE_URL', 'https://athinaregalweaves.com');

// Upload settings
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_SIZE', 50 * 1024 * 1024); // 50MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);

// Token settings
define('ADMIN_TOKEN_EXPIRY', '+24 hours');
define('CUSTOMER_TOKEN_EXPIRY', '+7 days');
define('OTP_EXPIRY', '+15 minutes');

// Razorpay (replace with your actual keys)
define('RAZORPAY_KEY_ID', 'YOUR_RAZORPAY_KEY_ID');
define('RAZORPAY_KEY_SECRET', 'YOUR_RAZORPAY_KEY_SECRET');

// Database credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'u586955688_athinaregal');
define('DB_USER', 'u586955688_athinaregal');
define('DB_PASS', 'Athinaregalwaves@14O2');
?>
