<?php
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// ─── GET: Get all assignments ───
if ($method === 'GET' && $action === 'list') {
    $stmt = $pdo->query("SELECT product_id, collection_type FROM collection_assignments ORDER BY created_at DESC");
    $rows = $stmt->fetchAll();

    $grouped = [];
    foreach ($rows as $row) {
        $pid = $row['product_id'];
        if (!isset($grouped[$pid])) $grouped[$pid] = [];
        $grouped[$pid][] = $row['collection_type'];
    }
    echo json_encode($grouped);
}

// ─── GET: Get collections for a product ───
elseif ($method === 'GET' && $action === 'get') {
    $productId = $_GET['product_id'] ?? '';
    if (!$productId) {
        http_response_code(400);
        echo json_encode(['error' => 'Product ID required']);
        exit();
    }

    $stmt = $pdo->prepare("SELECT collection_type FROM collection_assignments WHERE product_id = ?");
    $stmt->execute([$productId]);
    $types = array_column($stmt->fetchAll(), 'collection_type');
    echo json_encode($types);
}

// ─── POST: Add product to collection ───
elseif ($method === 'POST' && $action === 'add') {
    validateToken();
    $input = json_decode(file_get_contents('php://input'), true);
    $productId = $input['product_id'] ?? '';
    $collection = $input['collection_type'] ?? '';

    if (!$productId || !in_array($collection, ['bridal', 'tissue', 'linen'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Valid product_id and collection_type required']);
        exit();
    }

    // Get product name for history
    $stmt = $pdo->prepare("SELECT item_name FROM admin_products WHERE product_id = ?");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    $productName = $product['item_name'] ?? $productId;

    $stmt = $pdo->prepare("INSERT IGNORE INTO collection_assignments (product_id, collection_type) VALUES (?, ?)");
    $stmt->execute([$productId, $collection]);

    $pdo->prepare("INSERT INTO edit_history (page, action, item_name) VALUES ('collections', ?, ?)")
        ->execute(["Added to $collection", $productName]);

    echo json_encode(['success' => true]);
}

// ─── DELETE: Remove product from collection ───
elseif ($method === 'DELETE' && $action === 'remove') {
    validateToken();
    $productId = $_GET['product_id'] ?? '';
    $collection = $_GET['collection_type'] ?? '';

    if (!$productId || !$collection) {
        http_response_code(400);
        echo json_encode(['error' => 'product_id and collection_type required']);
        exit();
    }

    $pdo->prepare("DELETE FROM collection_assignments WHERE product_id = ? AND collection_type = ?")->execute([$productId, $collection]);

    // Get product name for history
    $stmt = $pdo->prepare("SELECT item_name FROM admin_products WHERE product_id = ?");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    $productName = $product['item_name'] ?? $productId;

    $pdo->prepare("INSERT INTO edit_history (page, action, item_name) VALUES ('collections', ?, ?)")
        ->execute(["Removed from $collection", $productName]);

    echo json_encode(['success' => true]);
}

else {
    http_response_code(404);
    echo json_encode(['error' => 'Unknown action']);
}
?>
