<?php
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM homepage_sections WHERE is_active = 1 ORDER BY id ASC");
    echo json_encode($stmt->fetchAll());

} elseif ($method === 'PUT') {
    $user = validateToken();
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $_GET['id'] ?? '';

    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'Section ID required']);
        exit();
    }

    $fields = [];
    $values = [];

    $allowed = ['title', 'subtitle', 'description', 'image_url', 'image_width', 'image_height', 'redirect_page', 'button_text', 'caption', 'is_active'];

    foreach ($allowed as $field) {
        if (isset($input[$field])) {
            $fields[] = "$field = ?";
            $values[] = $input[$field];
        }
    }

    if (empty($fields)) {
        http_response_code(400);
        echo json_encode(['error' => 'No fields to update']);
        exit();
    }

    $values[] = $id;
    $sql = "UPDATE homepage_sections SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($values);

    // Log to history
    $stmt2 = $pdo->prepare("SELECT section_key FROM homepage_sections WHERE id = ?");
    $stmt2->execute([$id]);
    $section = $stmt2->fetch();
    if ($section) {
        $pdo->prepare("INSERT INTO edit_history (page, action, item_name) VALUES ('sections', 'Updated section', ?)")
            ->execute([$section['section_key']]);
    }

    $stmt = $pdo->prepare("SELECT * FROM homepage_sections WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode($stmt->fetch());
}
?>
