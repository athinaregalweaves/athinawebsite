<?php
require_once __DIR__ . '/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);
$action = $_GET['action'] ?? '';

// ─── CREATE ORDER ───
if ($method === 'POST' && $action === 'create') {
    $name = trim($input['name'] ?? '');
    $email = trim($input['email'] ?? '');
    $phone = trim($input['phone'] ?? '');
    $address = trim($input['address'] ?? '');
    $city = trim($input['city'] ?? '');
    $state = trim($input['state'] ?? '');
    $pincode = trim($input['pincode'] ?? '');
    $items = $input['items'] ?? [];
    $total = floatval($input['total'] ?? 0);
    $customerId = intval($input['customer_id'] ?? 0);

    if (!$name || !$email || !$phone || !$address || !$city || !$state || !$pincode) {
        http_response_code(400);
        echo json_encode(['error' => 'All address fields are required']);
        exit();
    }
    if (empty($items) || $total <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Cart is empty']);
        exit();
    }

    $orderNumber = 'ATH-' . strtoupper(substr(uniqid(), -8));

    $stmt = $pdo->prepare("INSERT INTO orders (order_number, customer_id, customer_name, customer_email, customer_phone, address, city, state, pincode, total_amount, status, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending')");
    $stmt->execute([$orderNumber, $customerId ?: null, $name, $email, $phone, $address, $city, $state, $pincode, $total]);
    $orderId = $pdo->lastInsertId();

    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, product_name, product_sku, price, quantity) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($items as $item) {
        $stmt->execute([
            $orderId,
            $item['product_id'],
            $item['product_name'],
            $item['product_sku'] ?? '',
            $item['price'],
            $item['quantity'],
        ]);
    }

    sendOrderEmail($email, $name, $orderNumber, $items, $total);

    echo json_encode([
        'success' => true,
        'order_id' => $orderId,
        'order_number' => $orderNumber,
    ]);
}

// ─── INITIATE RAZORPAY PAYMENT ───
elseif ($method === 'POST' && $action === 'create-payment') {
    $orderId = intval($input['order_id'] ?? 0);
    $amount = floatval($input['amount'] ?? 0);

    if (!$orderId || $amount <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid order or amount']);
        exit();
    }

    $razorpayKey = RAZORPAY_KEY_ID;
    $razorpaySecret = RAZORPAY_KEY_SECRET;

    $orderData = [
        'amount' => $amount * 100,
        'currency' => 'INR',
        'receipt' => 'order_' . $orderId,
        'notes' => ['order_id' => $orderId],
    ];

    $ch = curl_init('https://api.razorpay.com/v1/orders');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($orderData),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_USERPWD => "$razorpayKey:$razorpaySecret",
        CURLOPT_TIMEOUT => 30,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        http_response_code(500);
        echo json_encode(['error' => 'Payment gateway error']);
        exit();
    }

    $razorpayOrder = json_decode($response, true);

    $stmt = $pdo->prepare("UPDATE orders SET razorpay_order_id = ? WHERE id = ?");
    $stmt->execute([$razorpayOrder['id'], $orderId]);

    echo json_encode([
        'razorpay_order_id' => $razorpayOrder['id'],
        'razorpay_key' => $razorpayKey,
        'amount' => $amount * 100,
        'currency' => 'INR',
    ]);
}

// ─── VERIFY PAYMENT ───
elseif ($method === 'POST' && $action === 'verify-payment') {
    $razorpayPaymentId = $input['razorpay_payment_id'] ?? '';
    $razorpayOrderId = $input['razorpay_order_id'] ?? '';
    $razorpaySignature = $input['razorpay_signature'] ?? '';
    $orderId = intval($input['order_id'] ?? 0);

    $expectedSignature = hash_hmac('sha256', $razorpayOrderId . '|' . $razorpayPaymentId, RAZORPAY_KEY_SECRET);

    if (hash_equals($expectedSignature, $razorpaySignature)) {
        $stmt = $pdo->prepare("UPDATE orders SET payment_status = 'paid', razorpay_payment_id = ?, status = 'confirmed' WHERE id = ?");
        $stmt->execute([$razorpayPaymentId, $orderId]);
        echo json_encode(['success' => true, 'message' => 'Payment verified']);
    } else {
        $stmt = $pdo->prepare("UPDATE orders SET payment_status = 'failed' WHERE id = ?");
        $stmt->execute([$orderId]);
        http_response_code(400);
        echo json_encode(['error' => 'Payment verification failed']);
    }
}

// ─── GET ORDER (by order number) ───
elseif ($method === 'GET' && $action === 'track') {
    $orderNumber = $_GET['order_number'] ?? '';
    if (!$orderNumber) {
        http_response_code(400);
        echo json_encode(['error' => 'Order number required']);
        exit();
    }

    $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_number = ?");
    $stmt->execute([$orderNumber]);
    $order = $stmt->fetch();

    if (!$order) {
        http_response_code(404);
        echo json_encode(['error' => 'Order not found']);
        exit();
    }

    $stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $stmt->execute([$order['id']]);
    $order['items'] = $stmt->fetchAll();
    echo json_encode($order);
}

// ─── MY ORDERS (for logged-in customer) ───
elseif ($method === 'GET' && $action === 'my-orders') {
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    if (!preg_match('/Bearer\s+(.+)/', $auth, $matches)) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit();
    }

    $token = $matches[1];
    $stmt = $pdo->prepare("SELECT id FROM customers WHERE token = ? AND token_expiry > NOW()");
    $stmt->execute([$token]);
    $customer = $stmt->fetch();

    if (!$customer) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid session']);
        exit();
    }

    $stmt = $pdo->prepare("SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC");
    $stmt->execute([$customer['id']]);
    echo json_encode($stmt->fetchAll());
}

// ─── ADMIN: LIST ALL ORDERS ───
elseif ($method === 'GET' && $action === 'admin-list') {
    validateToken();
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = 25;
    $offset = ($page - 1) * $limit;

    $stmt = $pdo->query("SELECT COUNT(*) FROM orders");
    $total = $stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT * FROM orders ORDER BY created_at DESC LIMIT ? OFFSET ?");
    $stmt->execute([$limit, $offset]);
    $orders = $stmt->fetchAll();

    echo json_encode(['orders' => $orders, 'total' => $total, 'page' => $page, 'pages' => ceil($total / $limit)]);
}

// ─── ADMIN: UPDATE ORDER STATUS ───
elseif ($method === 'PUT' && $action === 'update-status') {
    validateToken();
    $orderId = intval($_GET['id'] ?? 0);
    $status = $input['status'] ?? '';
    $validStatuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];

    if (!in_array($status, $validStatuses)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid status']);
        exit();
    }

    $stmt = $pdo->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$status, $orderId]);
    echo json_encode(['success' => true]);
}

// ─── HELPERS ───

function sendOrderEmail($to, $name, $orderNumber, $items, $total) {
    $itemsHtml = '';
    foreach ($items as $item) {
        $subtotal = $item['price'] * $item['quantity'];
        $itemsHtml .= '<tr>
            <td style="padding:8px 12px;border-bottom:1px solid #e8e0d8;font-size:14px;">' . htmlspecialchars($item['product_name']) . '</td>
            <td style="padding:8px 12px;border-bottom:1px solid #e8e0d8;font-size:14px;text-align:center;">' . $item['quantity'] . '</td>
            <td style="padding:8px 12px;border-bottom:1px solid #e8e0d8;font-size:14px;text-align:right;">₹' . number_format($subtotal) . '</td>
        </tr>';
    }

    $html = '<!DOCTYPE html><html><body style="font-family:Georgia,serif;background:#FAF8F5;padding:40px 20px;">
    <div style="max-width:600px;margin:0 auto;background:#fff;border:1px solid #e8e0d8;padding:40px;">
        <div style="text-align:center;margin-bottom:30px;">
            <div style="display:inline-block;border-left:3px solid #C4A265;padding-left:12px;">
                <div style="font-size:20px;letter-spacing:0.25em;font-weight:bold;color:#1a1a1a;">ATHINA</div>
                <div style="font-size:9px;letter-spacing:0.4em;color:#C4A265;margin-top:4px;">REGAL WEAVES</div>
            </div>
        </div>
        <h2 style="text-align:center;color:#722F37;font-size:22px;margin:0 0 10px;">Order Confirmation</h2>
        <p style="text-align:center;color:#555;font-size:14px;">Dear ' . htmlspecialchars($name) . ',</p>
        <p style="text-align:center;color:#555;font-size:14px;">Thank you for your order! Your order number is:</p>
        <div style="text-align:center;margin:20px 0;">
            <span style="display:inline-block;background:#722F37;color:#FAF8F5;font-size:18px;letter-spacing:0.2em;padding:12px 24px;font-weight:bold;">' . $orderNumber . '</span>
        </div>
        <table style="width:100%;border-collapse:collapse;margin:20px 0;">
            <tr style="background:#f5f0eb;">
                <th style="padding:10px 12px;text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:0.1em;">Item</th>
                <th style="padding:10px 12px;text-align:center;font-size:12px;text-transform:uppercase;">Qty</th>
                <th style="padding:10px 12px;text-align:right;font-size:12px;text-transform:uppercase;">Amount</th>
            </tr>
            ' . $itemsHtml . '
            <tr>
                <td colspan="2" style="padding:12px;font-size:16px;font-weight:bold;text-align:right;">Total:</td>
                <td style="padding:12px;font-size:16px;font-weight:bold;text-align:right;color:#722F37;">₹' . number_format($total) . '</td>
            </tr>
        </table>
        <p style="text-align:center;color:#999;font-size:12px;margin-top:30px;">We will notify you once your order is shipped.</p>
        <hr style="border:none;border-top:1px solid #e8e0d8;margin:30px 0;">
        <p style="text-align:center;color:#999;font-size:11px;">' . SITE_NAME . ' · Hyderabad · Heritage Handloom</p>
    </div></body></html>';

    $headers = "From: " . SITE_NAME . " <" . SITE_EMAIL . ">\r\n";
    $headers .= "Reply-To: " . SITE_EMAIL . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    mail($to, "Order Confirmed - $orderNumber | " . SITE_NAME, $html, $headers);
}
?>
